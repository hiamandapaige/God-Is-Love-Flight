import React from 'react';
import Navbar from '@/components/site/Navbar';
import Hero from '@/components/site/Hero';
import About from '@/components/site/About';
import Services from '@/components/site/Services';
import FlightReel from '@/components/site/FlightReel';
import Academy from '@/components/site/Academy';
import ClassForm from '@/components/site/ClassForm';
import Footer from '@/components/site/Footer';

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        <Hero />
        <About />
        <Services />
        <FlightReel />
        <Academy />
        <ClassForm />
      </main>
      <Footer />
    </div>
  );
}