import React from 'react';

// Digital illustration of the Betta Body Butta jar — black ribbed lid, clear body,
// cream product visible, dark marbled label. Matches the real product photo.
export default function SheaDisplay() {
  return (
    <svg viewBox="0 0 300 400" className="w-full h-full drop-shadow-2xl">
      <defs>
        {/* warm oak wood surface */}
        <linearGradient id="wood" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#E6C291" />
          <stop offset="50%" stopColor="#D2A679" />
          <stop offset="100%" stopColor="#B88A55" />
        </linearGradient>
        {/* clear plastic jar */}
        <linearGradient id="plastic" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="rgba(220,225,230,0.55)" />
          <stop offset="12%" stopColor="rgba(255,255,255,0.78)" />
          <stop offset="30%" stopColor="rgba(245,247,250,0.30)" />
          <stop offset="70%" stopColor="rgba(235,238,242,0.30)" />
          <stop offset="90%" stopColor="rgba(200,208,216,0.65)" />
          <stop offset="100%" stopColor="rgba(150,160,172,0.75)" />
        </linearGradient>
        {/* cream product inside */}
        <linearGradient id="cream" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#EAD7B0" />
          <stop offset="40%" stopColor="#F3E7CE" />
          <stop offset="100%" stopColor="#E2CFA6" />
        </linearGradient>
        {/* black ribbed lid */}
        <linearGradient id="lidTop" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#2E2E2E" />
          <stop offset="100%" stopColor="#1A1A1A" />
        </linearGradient>
        <linearGradient id="lidSide" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#0D0D0D" />
          <stop offset="50%" stopColor="#1A1A1A" />
          <stop offset="100%" stopColor="#0D0D0D" />
        </linearGradient>
        {/* dark marbled label */}
        <linearGradient id="labelBg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#2a1c12" />
          <stop offset="50%" stopColor="#1c130a" />
          <stop offset="100%" stopColor="#0D0D0D" />
        </linearGradient>
        <linearGradient id="labelShade" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="rgba(0,0,0,0.55)" />
          <stop offset="15%" stopColor="rgba(0,0,0,0)" />
          <stop offset="85%" stopColor="rgba(0,0,0,0)" />
          <stop offset="100%" stopColor="rgba(0,0,0,0.55)" />
        </linearGradient>
        <radialGradient id="creamSheen" cx="0.32" cy="0.3" r="0.7">
          <stop offset="0%" stopColor="rgba(255,255,255,0.5)" />
          <stop offset="60%" stopColor="rgba(255,255,255,0)" />
        </radialGradient>
      </defs>

      {/* wood surface */}
      <rect x="0" y="300" width="300" height="100" fill="url(#wood)" />
      <g stroke="#A67842" strokeWidth="1.2" opacity="0.45" fill="none">
        <path d="M0,318 C60,316 120,320 180,317 S280,319 300,318" />
        <path d="M0,332 C50,335 130,330 200,333 S270,331 300,333" />
        <path d="M0,348 C70,346 140,350 210,347 S280,349 300,348" />
        <path d="M0,364 C40,362 110,366 190,363 S260,365 300,364" />
        <path d="M0,380 C60,378 120,382 200,379 S280,381 300,380" />
      </g>

      {/* ground shadow */}
      <ellipse cx="150" cy="356" rx="92" ry="11" fill="rgba(60,40,20,0.28)" />

      {/* ===== JAR ===== */}
      {/* cream product body (visible through clear plastic) */}
      <path d="M86,112 h128 a8 8 0 0 1 8 8 v224 a16 16 0 0 1 -16 16 h-112 a16 16 0 0 1 -16 -16 v-224 a8 8 0 0 1 8 -8 z" fill="url(#cream)" />
      {/* product top surface */}
      <ellipse cx="150" cy="112" rx="64" ry="7" fill="#EAD7B0" />
      <ellipse cx="150" cy="112" rx="64" ry="7" fill="url(#creamSheen)" />

      {/* clear plastic shell over the product */}
      <path d="M80,104 h140 a8 8 0 0 1 8 8 v232 a16 16 0 0 1 -16 16 h-124 a16 16 0 0 1 -16 -16 v-232 a8 8 0 0 1 8 -8 z" fill="url(#plastic)" />
      {/* plastic vertical highlight */}
      <path d="M96,112 h10 v224 h-10 z" fill="rgba(255,255,255,0.35)" />
      <path d="M198,112 h6 v224 h-6 z" fill="rgba(120,128,138,0.35)" />

      {/* ===== LABEL (dark marbled, wraps the jar) ===== */}
      <rect x="86" y="158" width="128" height="172" fill="url(#labelBg)" />
      {/* marble / shea-nut organic veins */}
      <g opacity="0.5">
        <path d="M92,168 C120,176 150,164 176,172 S206,168 210,176" stroke="#4a3520" strokeWidth="2" fill="none" />
        <path d="M88,196 C110,190 140,202 168,194 S204,198 214,192" stroke="#3a2818" strokeWidth="1.6" fill="none" />
        <path d="M90,300 C116,308 146,296 174,304 S206,300 212,306" stroke="#4a3520" strokeWidth="2" fill="none" />
        <circle cx="104" cy="288" r="9" fill="#33241a" opacity="0.5" />
        <circle cx="196" cy="180" r="7" fill="#33241a" opacity="0.5" />
        <circle cx="118" cy="312" r="5" fill="#33241a" opacity="0.5" />
      </g>
      {/* cylinder edge shading */}
      <rect x="86" y="158" width="128" height="172" fill="url(#labelShade)" />

      {/* brand name */}
      <text x="150" y="186" textAnchor="middle" fontFamily="'Playfair Display', serif" fontStyle="italic" fontWeight="700" fontSize="17" fill="#EAD9B5">Betta Body</text>
      <text x="150" y="206" textAnchor="middle" fontFamily="'Playfair Display', serif" fontStyle="italic" fontWeight="700" fontSize="17" fill="#EAD9B5">Butta</text>

      <line x1="104" y1="218" x2="196" y2="218" stroke="#EAD9B5" strokeWidth="0.8" opacity="0.5" />

      {/* description */}
      <text x="150" y="232" textAnchor="middle" fontFamily="'Inter', sans-serif" fontSize="6.2" fill="#D9C7A0">Great for dry hair, scalp,</text>
      <text x="150" y="241" textAnchor="middle" fontFamily="'Inter', sans-serif" fontSize="6.2" fill="#D9C7A0">cracked heels, knees, elbows,</text>
      <text x="150" y="250" textAnchor="middle" fontFamily="'Inter', sans-serif" fontSize="6.2" fill="#D9C7A0">eczema, psoriasis, scars,</text>
      <text x="150" y="259" textAnchor="middle" fontFamily="'Inter', sans-serif" fontSize="6.2" fill="#D9C7A0">stretch marks, wrinkles &amp; more</text>

      {/* contact */}
      <text x="150" y="278" textAnchor="middle" fontFamily="'Inter', sans-serif" fontWeight="600" fontSize="7" fill="#EAD9B5">Contact: (601) 573-7624</text>

      {/* footer */}
      <text x="150" y="318" textAnchor="middle" fontFamily="'Inter', sans-serif" fontSize="6" fill="#C9B68C" opacity="0.75">Brocher</text>

      {/* ===== LID (black, ribbed) ===== */}
      {/* lid side wall */}
      <rect x="86" y="86" width="128" height="22" fill="url(#lidSide)" />
      {/* ribs */}
      <g stroke="rgba(0,0,0,0.6)" strokeWidth="2">
        {[92, 100, 108, 116, 124, 132, 140, 148, 156, 164, 172, 180, 188, 196, 204].map((x) => (
          <line key={x} x1={x} y1="88" x2={x} y2="106" />
        ))}
      </g>
      <g stroke="rgba(255,255,255,0.06)" strokeWidth="1">
        {[96, 104, 112, 120, 128, 136, 144, 152, 160, 168, 176, 184, 192, 200].map((x) => (
          <line key={x} x1={x} y1="88" x2={x} y2="106" />
        ))}
      </g>
      {/* lid top */}
      <ellipse cx="150" cy="86" rx="64" ry="9" fill="url(#lidTop)" />
      <ellipse cx="150" cy="86" rx="64" ry="9" fill="rgba(255,255,255,0.06)" />
      {/* central mold dimple */}
      <ellipse cx="150" cy="86" rx="10" ry="3.5" fill="#0D0D0D" />
      <ellipse cx="150" cy="85" rx="10" ry="3.5" fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="0.8" />
      {/* lid top sheen */}
      <ellipse cx="132" cy="83" rx="26" ry="3" fill="rgba(255,255,255,0.18)" />
    </svg>
  );
}