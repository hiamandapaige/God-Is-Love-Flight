import React from 'react';

/**
 * Renders a single cross from a shared photo that contains multiple crosses
 * laid out horizontally. Uses background-position so each cross is shown
 * crisply on its own, with no distortion.
 *
 * @param {string} src       - the shared photo URL
 * @param {number} index     - 0-based index of the cross to show
 * @param {number} total=3   - total number of crosses in the photo
 */
export default function CrossVariantImage({ src, index, total = 3, className = '' }) {
  const pct = total > 1 ? (index / (total - 1)) * 100 : 50;
  return (
    <div
      className={className}
      role="img"
      style={{
        backgroundImage: `url(${src})`,
        backgroundSize: 'auto 100%',
        backgroundPosition: `${pct}% center`,
        backgroundRepeat: 'no-repeat',
        width: '100%',
        height: '100%',
      }}
    />
  );
}