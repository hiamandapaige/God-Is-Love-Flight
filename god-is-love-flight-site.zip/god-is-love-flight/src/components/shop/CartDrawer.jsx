import React from 'react';
import { X, Minus, Plus, Trash2 } from 'lucide-react';
import { useCart } from '@/components/shop/CartContext';

export default function CartDrawer({ open, onClose, onCheckout }) {
  const { items, updateQty, removeItem, subtotal, count } = useCart();
  return (
    <>
      <div className={`fixed inset-0 z-50 bg-space/40 transition-opacity ${open ? 'opacity-100' : 'opacity-0 pointer-events-none'}`} onClick={onClose} />
      <aside className={`fixed top-0 right-0 z-50 h-full w-full max-w-md bg-background shadow-2xl transition-transform ${open ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="flex items-center justify-between h-16 px-5 border-b border-border">
          <p className="font-mono-tech font-semibold text-sm uppercase tracking-widest">Your Cart {count > 0 && `(${count})`}</p>
          <button onClick={onClose} className="p-2 hover:text-gold transition"><X size={20} /></button>
        </div>

        <div className="flex flex-col h-[calc(100%-4rem)]">
          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {items.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center text-muted-foreground">
                <p className="font-mono-tech text-sm uppercase tracking-widest">Your cart is empty</p>
                <p className="mt-2 text-sm">Add a product to get started.</p>
              </div>
            ) : items.map((i) => (
              <div key={i.key} className="glass-panel rounded-2xl p-4">
                <div className="flex justify-between gap-3">
                  <div>
                    <p className="font-mono-tech font-semibold text-sm">{i.name}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{i.options}</p>
                  </div>
                  <button onClick={() => removeItem(i.key)} className="text-muted-foreground hover:text-destructive transition"><Trash2 size={16} /></button>
                </div>
                <div className="mt-3 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <button onClick={() => updateQty(i.key, i.qty - 1)} className="h-8 w-8 rounded-lg border border-border flex items-center justify-center hover:border-sky"><Minus size={14} /></button>
                    <span className="w-8 text-center text-sm font-mono-tech">{i.qty}</span>
                    <button onClick={() => updateQty(i.key, i.qty + 1)} className="h-8 w-8 rounded-lg border border-border flex items-center justify-center hover:border-sky"><Plus size={14} /></button>
                  </div>
                  <p className="font-mono-tech font-semibold">${(i.price * i.qty).toFixed(2)}</p>
                </div>
              </div>
            ))}
          </div>

          {items.length > 0 && (
            <div className="border-t border-border p-5 space-y-4">
              <div className="flex justify-between font-mono-tech">
                <span className="text-muted-foreground">Subtotal</span>
                <span className="text-xl font-bold">${subtotal.toFixed(2)}</span>
              </div>
              <button onClick={onCheckout} className="h-12 w-full inline-flex items-center justify-center rounded-full bg-gold px-6 font-mono-tech text-sm uppercase tracking-widest text-gold-foreground hover:animate-hover-stabilize gold-glow transition">
                Checkout Securely
              </button>
              <p className="text-center text-xs text-muted-foreground">Payment is confirmed when we fulfill your order.</p>
            </div>
          )}
        </div>
      </aside>
    </>
  );
}