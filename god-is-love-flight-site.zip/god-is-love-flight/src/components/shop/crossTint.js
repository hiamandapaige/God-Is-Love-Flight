// Cross photo + live tint helper.
// The source cross photo is blue (~220° hue); we shift hue to approximate the
// customer's chosen body color. Achromatic colors (black/white/grey) desaturate.
export const CROSS_IMAGE = '/media/cross-variant-1.png';
export const UPLOADED_CROSS = '/media/cross-variant-2.png';
const SOURCE_HUE = 220;

function hexToHue(hex) {
  let h = (hex || '').replace('#', '');
  if (h.length === 3) h = h.split('').map((c) => c + c).join('');
  if (h.length !== 6) return null;
  const r = parseInt(h.slice(0, 2), 16) / 255;
  const g = parseInt(h.slice(2, 4), 16) / 255;
  const b = parseInt(h.slice(4, 6), 16) / 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  if (max === min) return null; // achromatic
  const d = max - min;
  let hue = 0;
  if (max === r) hue = (g - b) / d + (g < b ? 6 : 0);
  else if (max === g) hue = (b - r) / d + 2;
  else hue = (r - g) / d + 4;
  return hue * 60;
}

function hexToMax(hex) {
  let h = (hex || '').replace('#', '');
  if (h.length === 3) h = h.split('').map((c) => c + c).join('');
  if (h.length !== 6) return 1;
  const r = parseInt(h.slice(0, 2), 16) / 255;
  const g = parseInt(h.slice(2, 4), 16) / 255;
  const b = parseInt(h.slice(4, 6), 16) / 255;
  return Math.max(r, g, b);
}

export function tintFilter(hex) {
  const hue = hexToHue(hex);
  if (hue === null) {
    const lum = hexToMax(hex);
    if (lum < 0.18) return 'saturate(0) brightness(0.08)';
    if (lum > 0.85) return 'saturate(0) brightness(1.8)';
    return `saturate(0) brightness(${(lum * 1.9).toFixed(2)})`;
  }
  return `hue-rotate(${Math.round(hue - SOURCE_HUE)}deg) saturate(1.12)`;
}