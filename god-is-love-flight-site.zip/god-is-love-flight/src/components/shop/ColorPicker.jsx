import React from 'react';
import { Check } from 'lucide-react';

const PRESETS = [
  { name: 'Gold', color: '#D4A017' },
  { name: 'Silver', color: '#C0C0C0' },
  { name: 'Black', color: '#222222' },
  { name: 'White', color: '#FFFFFF' },
  { name: 'Red', color: '#D42628' },
  { name: 'Blue', color: '#2A60B0' },
  { name: 'Green', color: '#2E8B57' },
  { name: 'Purple', color: '#6A4C93' },
  { name: 'Pink', color: '#E91E63' },
  { name: 'Orange', color: '#FF8C00' },
  { name: 'Yellow', color: '#F1B434' },
];

export default function ColorPicker({ value, onChange, label = 'Color' }) {
  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <p className="text-xs font-semibold uppercase tracking-widest text-gray-500">{label}</p>
        <span className="text-xs font-mono text-gray-400 uppercase">{value}</span>
      </div>
      <div className="flex flex-wrap gap-2 mb-3">
        {PRESETS.map((p) => {
          const active = value.toLowerCase() === p.color.toLowerCase();
          return (
            <button
              key={p.color}
              type="button"
              onClick={() => onChange(p.color)}
              title={p.name}
              className={`relative w-9 h-9 rounded-full border-2 transition ${active ? 'border-foreground scale-110 shadow' : 'border-gray-200 hover:border-gray-400'}`}
              style={{ backgroundColor: p.color }}
            >
              {active && <Check size={16} className="absolute inset-0 m-auto text-white drop-shadow" />}
            </button>
          );
        })}
      </div>
      <label className="flex items-center gap-3 cursor-pointer">
        <span className="relative w-9 h-9 rounded-full border-2 border-gray-200 overflow-hidden" style={{ backgroundColor: value }}>
          <input type="color" value={value} onChange={(e) => onChange(e.target.value)} className="absolute opacity-0 w-full h-full cursor-pointer" />
        </span>
        <span className="text-sm text-gray-500">Custom — pick any shade on the wheel</span>
      </label>
    </div>
  );
}