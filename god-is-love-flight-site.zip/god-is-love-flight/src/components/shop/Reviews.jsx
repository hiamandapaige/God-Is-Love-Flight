import React from 'react';
import { Star, Quote } from 'lucide-react';

const REVIEWS = [
  {
    name: 'Marcus T.',
    location: 'Jackson, MS',
    rating: 5,
    text: 'The God Is Love Cross is stunning. The detail on the lettering is crisp and it feels solid in hand. Wearing it daily as a reminder of 1 John 4:8.',
    product: 'God Is Love Cross',
  },
  {
    name: 'Danielle R.',
    location: 'Brandon, MS',
    rating: 5,
    text: 'Betta Body Butta saved my cracked heels and dry scalp. A little goes a long way and the Savage scent is unreal. Hands down the best body butter I own.',
    product: 'Betta Body Butta',
  },
  {
    name: 'Pastor Williams',
    location: 'Byram, MS',
    rating: 5,
    text: 'Ordered crosses for our youth group — every single one was beautiful and meaningful. Fast, kind service and a product that points people to love.',
    product: 'God Is Love Cross',
  },
];

function Stars({ rating }) {
  return (
    <div className="flex gap-0.5">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star key={i} size={15} className={i < rating ? 'fill-gold text-gold' : 'text-gray-300'} />
      ))}
    </div>
  );
}

export default function Reviews() {
  return (
    <section className="mb-16">
      <div className="text-center mb-10">
        <p className="text-xs uppercase tracking-[0.2em] text-gray-400 mb-2">Loved By Our Community</p>
        <h2 className="font-display italic text-3xl sm:text-4xl text-black">What Customers Are Saying</h2>
        <div className="flex items-center justify-center gap-2 mt-3">
          <Stars rating={5} />
          <span className="text-sm text-gray-500">5.0 · Based on real reviews</span>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-5">
        {REVIEWS.map((r) => (
          <div key={r.name} className="relative rounded-2xl border border-gray-100 bg-white p-6 shadow-sm flex flex-col">
            <Quote size={28} className="text-gold/25 absolute top-5 right-5" />
            <Stars rating={r.rating} />
            <p className="text-sm text-gray-600 leading-relaxed mt-4 flex-1">"{r.text}"</p>
            <div className="flex items-center gap-3 mt-5 pt-5 border-t border-gray-100">
              <span className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-gold/15 text-gold font-semibold text-sm">
                {r.name.charAt(0)}
              </span>
              <div>
                <p className="text-sm font-semibold text-black leading-tight">{r.name}</p>
                <p className="text-xs text-gray-400">{r.location} · {r.product}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}