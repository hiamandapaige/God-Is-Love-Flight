import React from 'react';

// Professional digital product render of the real Betta Body Butta jar.
// Matte black ribbed lid with center sprue point, white cylindrical body,
// warm-cream label with night-forest silhouette, golden bokeh, full label text.
export default function BettaJar({ className }) {
  return (
    <svg viewBox="0 0 300 400" className={className} xmlns="http://www.w3.org/2000/svg">
      <defs>
        {/* Wood surface */}
        <linearGradient id="wood" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#C19A6B" />
          <stop offset="100%" stopColor="#A0744A" />
        </linearGradient>
        {/* Lid — matte black cylindrical */}
        <linearGradient id="lidGrad" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#2E2E2E" />
          <stop offset="15%" stopColor="#1F1F1F" />
          <stop offset="50%" stopColor="#0E0E0E" />
          <stop offset="85%" stopColor="#1A1A1A" />
          <stop offset="100%" stopColor="#282828" />
        </linearGradient>
        {/* Jar body — white cylindrical (7-stop for curvature) */}
        <linearGradient id="jarGrad" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#C8C8C8" />
          <stop offset="8%" stopColor="#E0E0E0" />
          <stop offset="22%" stopColor="#F4F4F4" />
          <stop offset="42%" stopColor="#FFFFFF" />
          <stop offset="62%" stopColor="#FAFAFA" />
          <stop offset="82%" stopColor="#E5E5E5" />
          <stop offset="100%" stopColor="#B8B8B8" />
        </linearGradient>
        {/* Label cream background */}
        <linearGradient id="labelBg" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#F5E6CC" />
          <stop offset="100%" stopColor="#EDD5A8" />
        </linearGradient>
        {/* Night forest background */}
        <linearGradient id="nightBg" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#1E231D" />
          <stop offset="100%" stopColor="#2A3025" />
        </linearGradient>
        {/* Bokeh glows */}
        <radialGradient id="bokeh" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#E6B873" stopOpacity="0.95" />
          <stop offset="50%" stopColor="#D4A05A" stopOpacity="0.5" />
          <stop offset="100%" stopColor="#C09040" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="bokehSm" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#FFE0A0" stopOpacity="0.9" />
          <stop offset="100%" stopColor="#E6B873" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="bokehTiny" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#FFF0C0" stopOpacity="0.85" />
          <stop offset="100%" stopColor="#FFE0A0" stopOpacity="0" />
        </radialGradient>
        <clipPath id="labelClip">
          <rect x="70" y="165" width="160" height="165" rx="2" />
        </clipPath>
        {/* Soft jar shadow */}
        <filter id="jarShadow" x="-10%" y="-5%" width="120%" height="110%">
          <feDropShadow dx="4" dy="6" stdDeviation="6" floodOpacity="0.2" />
        </filter>
      </defs>

      {/* Wood surface */}
      <rect x="0" y="345" width="300" height="55" fill="url(#wood)" />
      <line x1="0" y1="358" x2="300" y2="360" stroke="rgba(100,60,20,0.15)" strokeWidth="1" />
      <line x1="0" y1="375" x2="300" y2="376" stroke="rgba(100,60,20,0.12)" strokeWidth="1" />
      <line x1="0" y1="390" x2="300" y2="391" stroke="rgba(100,60,20,0.1)" strokeWidth="1" />

      {/* Jar contact shadow */}
      <ellipse cx="155" cy="353" rx="92" ry="9" fill="rgba(0,0,0,0.22)" />

      {/* Jar body */}
      <g filter="url(#jarShadow)">
        <rect x="70" y="115" width="160" height="240" rx="6" fill="url(#jarGrad)" />
      </g>
      <ellipse cx="150" cy="355" rx="80" ry="7" fill="#B8B8B8" />

      {/* Lid */}
      <rect x="76" y="68" width="148" height="50" rx="4" fill="url(#lidGrad)" />
      <ellipse cx="150" cy="68" rx="74" ry="11" fill="#1A1A1A" />
      <ellipse cx="150" cy="66" rx="74" ry="8" fill="#0D0D0D" />
      {/* Lid top highlight */}
      <ellipse cx="150" cy="63" rx="50" ry="2.5" fill="rgba(255,255,255,0.12)" />
      {/* Center sprue point */}
      <circle cx="150" cy="65" r="2.5" fill="#060606" />
      <circle cx="149.5" cy="64.5" r="1" fill="rgba(255,255,255,0.1)" />
      {/* Ribbing */}
      {[76, 84, 92, 100, 108].map((y) => (
        <line key={`r${y}`} x1="78" y1={y} x2="222" y2={y} stroke="rgba(255,255,255,0.04)" strokeWidth="1.5" />
      ))}
      {[80, 88, 96, 104, 112].map((y) => (
        <line key={`d${y}`} x1="78" y1={y} x2="222" y2={y} stroke="rgba(0,0,0,0.4)" strokeWidth="1" />
      ))}

      {/* Label */}
      <rect x="70" y="165" width="160" height="165" rx="2" fill="url(#labelBg)" stroke="#D4C4A0" strokeWidth="0.5" />

      {/* Night forest band */}
      <g clipPath="url(#labelClip)">
        <rect x="70" y="165" width="160" height="68" fill="url(#nightBg)" />
        {/* Bokeh orbs — varied sizes */}
        <circle cx="92" cy="186" r="11" fill="url(#bokeh)" />
        <circle cx="128" cy="178" r="7" fill="url(#bokehSm)" />
        <circle cx="168" cy="188" r="10" fill="url(#bokeh)" />
        <circle cx="206" cy="182" r="6" fill="url(#bokehSm)" />
        <circle cx="108" cy="208" r="5" fill="url(#bokehSm)" />
        <circle cx="196" cy="214" r="7" fill="url(#bokeh)" />
        <circle cx="148" cy="198" r="4" fill="url(#bokehTiny)" />
        <circle cx="222" cy="200" r="5" fill="url(#bokehSm)" />
        <circle cx="82" cy="204" r="4" fill="url(#bokehTiny)" />
        <circle cx="135" cy="215" r="3" fill="url(#bokehTiny)" />
        <circle cx="180" cy="200" r="3.5" fill="url(#bokehTiny)" />
        <circle cx="115" cy="192" r="3" fill="url(#bokehTiny)" />
        {/* Tree silhouette */}
        <path
          d="M 150 233 L 150 186
             M 150 206 L 126 194 M 150 202 L 174 190
             M 150 196 L 134 180 M 150 194 L 168 176
             M 150 190 L 156 171
             M 150 212 L 120 218 M 150 214 L 180 220
             M 126 194 L 114 184 M 174 190 L 186 178
             M 134 180 L 124 168 M 168 176 L 176 162"
          stroke="#040404" strokeWidth="2.5" strokeLinecap="round" fill="none"
        />
        <ellipse cx="150" cy="188" rx="34" ry="38" fill="#050505" opacity="0.95" />
        <ellipse cx="130" cy="182" rx="17" ry="19" fill="#050505" opacity="0.9" />
        <ellipse cx="172" cy="184" rx="16" ry="18" fill="#050505" opacity="0.9" />
        <ellipse cx="112" cy="191" rx="12" ry="14" fill="#050505" opacity="0.85" />
        <ellipse cx="186" cy="188" rx="12" ry="13" fill="#050505" opacity="0.85" />
        <rect x="70" y="230" width="160" height="4" fill="#040404" />
      </g>

      {/* Title */}
      <text x="150" y="252" textAnchor="middle" fontFamily="'Playfair Display', serif" fontStyle="italic" fontWeight="700" fontSize="16" fill="#4E3629">Betta Body Butta</text>
      {/* Benefits */}
      <text x="150" y="266" textAnchor="middle" fontFamily="Inter, sans-serif" fontSize="5" fill="#4E3629">Great for dry hair, scalp, cracked heels,</text>
      <text x="150" y="273" textAnchor="middle" fontFamily="Inter, sans-serif" fontSize="5" fill="#4E3629">knees, elbows, eczema, psoriasis, scars,</text>
      <text x="150" y="280" textAnchor="middle" fontFamily="Inter, sans-serif" fontSize="5" fill="#4E3629">stretch marks, wrinkles, and more...</text>
      {/* Divider */}
      <line x1="95" y1="288" x2="205" y2="288" stroke="#C9B88E" strokeWidth="0.5" />
      {/* Contact */}
      <text x="150" y="298" textAnchor="middle" fontFamily="Inter, sans-serif" fontWeight="600" fontSize="5.5" fill="#4E3629">Contact: (601) 573-7624</text>
      {/* Warning */}
      <text x="150" y="314" textAnchor="middle" fontFamily="Inter, sans-serif" fontStyle="italic" fontSize="4.5" fill="#6B5340">*This product contains nut oils</text>

      {/* Jar cylindrical sheen — left highlight + right shadow */}
      <rect x="78" y="118" width="14" height="232" rx="7" fill="rgba(255,255,255,0.4)" />
      <rect x="208" y="118" width="14" height="232" rx="7" fill="rgba(0,0,0,0.06)" />
      {/* Upper rim highlight */}
      <ellipse cx="150" cy="116" rx="76" ry="2.5" fill="rgba(255,255,255,0.55)" />
    </svg>
  );
}