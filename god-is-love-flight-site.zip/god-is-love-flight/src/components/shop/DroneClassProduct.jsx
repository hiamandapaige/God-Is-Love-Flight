import React, { useState } from 'react';
import { useCart } from '@/components/shop/CartContext';
import { Plus, Check } from 'lucide-react';

const CURRICULUM = [
  'Preflight safety briefing and airspace check',
  'Hands-on controller orientation',
  'Guided first launch, hover & landing',
  'Flying in all directions, turning, changing directions smoothly',
  'Basic aerial photography capture',
  'Good habit instructions for responsible drone operation',
];

export default function DroneClassProduct() {
  const { addItem } = useCart();
  const [qty, setQty] = useState(1);
  const [added, setAdded] = useState(false);

  const add = () => {
    addItem({ key: 'drone_class', productId: 'drone_class', name: 'Drone Flight Instruction', price: 35, qty, options: '1 hr 15 min · Flight Readiness Session' });
    setAdded(true);
    setTimeout(() => setAdded(false), 1800);
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-20">
      <p className="font-mono-tech text-xs uppercase tracking-[0.3em] text-sky mb-3 text-center">// Hands-On Training</p>
      <h3 className="font-mono-tech font-bold text-3xl sm:text-4xl tracking-tight text-center">Flight Readiness Session</h3>
      <p className="mt-2 text-center font-display italic text-lg text-gold">Drone Pilot Class</p>
      <p className="mt-4 max-w-2xl mx-auto text-center text-muted-foreground">
        Learn how to fly a drone safely and confidently in a hands-on beginner class. The class is designed to build real flying skills step by step.
      </p>

      <div className="mt-12 grid lg:grid-cols-2 gap-10">
        <div className="glass-panel rounded-3xl p-8">
          <h4 className="font-mono-tech font-semibold text-lg mb-4">What Students Will Learn</h4>
          <ul className="space-y-2.5">
            {CURRICULUM.map((c) => (
              <li key={c} className="flex items-start gap-3 text-sm">
                <Check size={16} className="mt-0.5 shrink-0 text-sky" />
                <span>{c}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="space-y-6">
          <div className="glass-panel rounded-3xl p-8">
            <h4 className="font-mono-tech font-semibold text-lg mb-2">Class Practice</h4>
            <p className="text-sm text-muted-foreground">Students practice controlled takeoffs, precision landings, flying through a simple obstacle course, and completing beginner flight challenges. The goal is to help each student become more comfortable, accurate, and confident with the drone controls.</p>
          </div>
          <div className="glass-panel rounded-3xl p-8">
            <h4 className="font-mono-tech font-semibold text-lg mb-2">Who Can Attend</h4>
            <p className="text-sm text-muted-foreground">Beginner drone flyers are welcome — no previous flying experience is required. Class size, age requirements, location, and schedule are confirmed when you book.</p>
          </div>
          <div className="glass-panel rounded-3xl p-8">
            <div className="flex items-baseline justify-between">
              <p className="font-display italic text-2xl text-gold">Pilot Class</p>
              <p className="font-mono-tech text-3xl font-bold text-foreground">$35</p>
            </div>
            <p className="font-mono-tech text-[11px] uppercase tracking-widest text-sky mt-1">1 hr 15 min · Jackson, MS</p>
            <div className="mt-5 flex gap-3">
              <input type="number" min="1" value={qty} onChange={(e) => setQty(Math.max(1, Number(e.target.value) || 1))} className="w-24 h-12 rounded-xl border border-input bg-background px-4 text-sm focus:border-sky focus:outline-none focus:ring-2 focus:ring-sky/30" />
              <button onClick={add} className="flex-1 h-12 inline-flex items-center justify-center gap-2 rounded-full bg-gold px-6 font-mono-tech text-sm uppercase tracking-widest text-gold-foreground hover:animate-hover-stabilize gold-glow transition">
                {added ? <Check size={16} /> : <Plus size={16} />} {added ? 'Added' : 'Book a Class'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}