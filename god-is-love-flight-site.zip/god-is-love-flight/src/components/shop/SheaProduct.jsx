import React, { useState } from 'react';
import { useCart } from '@/components/shop/CartContext';
import { ShoppingBag, Phone, AlertTriangle, Plus, Minus, Check, Leaf, Heart, Shield } from 'lucide-react';
import { Image } from '@/components/ui/image';

const SCENTS = ['Plain', 'Savage', 'Vanilla Berry', 'Power'];

const BENEFITS = [
  'Dry hair & scalp',
  'Cracked heels',
  'Knees & elbows',
  'Eczema & psoriasis',
  'Scars & stretch marks',
  'Wrinkles',
];

const BADGES = [
  { icon: Leaf, label: 'All Natural Ingredients' },
  { icon: Heart, label: 'Handcrafted with Care' },
  { icon: Shield, label: 'Safe for Daily Use' },
];

export default function SheaProduct() {
  const { addItem } = useCart();
  const [scent, setScent] = useState('Plain');
  const [qty, setQty] = useState(1);

  const add = () => {
    addItem({ key: `shea|${scent}`, productId: 'shea', name: 'Betta Body Butta (8 oz)', price: 20, qty, options: `Scent: ${scent}` });
  };

  return (
    <section id="shop" className="py-12 sm:py-20 bg-cream">
      <div className="max-w-6xl mx-auto px-6">
        <p className="mb-8 text-sm text-gray-400">Home / Shop / Betta Body Butta</p>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Product image */}
          <div className="flex items-center justify-center">
            <Image src="/media/shea-product.png" fittingType="fit" originWidth={1024} originHeight={1024} quality={100} className="w-full max-w-[500px] h-auto drop-shadow-xl" />
          </div>

          {/* Product details */}
          <div className="space-y-5">
            <div>
              <p className="text-xs uppercase tracking-[0.3em] text-gold font-semibold mb-2">HANDCRAFTED BODY CARE</p>
              <h1 className="font-display italic text-4xl sm:text-5xl text-foreground leading-tight">Betta Body Butta</h1>
            </div>

            <div className="flex items-center gap-3">
              <p className="text-3xl font-bold text-foreground">$20.00</p>
              <span className="w-px h-8 bg-gray-300" />
              <p className="text-lg text-gray-500">8 oz. jar</p>
            </div>

            <p className="text-base text-gray-600 leading-relaxed">
              Great for dry hair, scalp, cracked heels, knees, elbows, eczema, psoriasis, scars, stretch marks, wrinkles, and more.
            </p>

            <div className="grid grid-cols-2 gap-x-6 gap-y-2 py-2">
              {BENEFITS.map((b) => (
                <div key={b} className="flex items-center gap-2 text-sm text-gray-700">
                  <Check size={15} className="text-gold shrink-0" /> {b}
                </div>
              ))}
            </div>

            <div className="flex items-start gap-2 rounded-xl bg-amber-50 border border-amber-200 px-4 py-3">
              <AlertTriangle size={16} className="text-amber-600 shrink-0 mt-0.5" />
              <p className="text-sm font-medium text-amber-700">This product contains nut oils.</p>
            </div>

            <div>
              <p className="text-xs uppercase tracking-widest text-gray-400 mb-3 font-semibold">SCENT</p>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {SCENTS.map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setScent(s)}
                    className={`h-11 rounded-xl border text-sm uppercase tracking-wider transition ${scent === s ? 'border-gold bg-gold/15 text-gold font-semibold' : 'border-gray-300 text-gray-500 hover:border-gold'}`}
                  >{s}</button>
                ))}
              </div>
            </div>

            <div className="flex gap-3 items-end pt-2">
              <div>
                <p className="text-xs uppercase tracking-widest text-gray-400 mb-2 font-semibold">QUANTITY</p>
                <div className="flex items-center border border-gray-300 rounded-xl h-12 bg-white">
                  <button type="button" onClick={() => setQty(Math.max(1, qty - 1))} className="px-4 h-full text-gray-500 hover:text-gold transition"><Minus size={16} /></button>
                  <span className="w-12 text-center text-sm font-medium">{qty}</span>
                  <button type="button" onClick={() => setQty(qty + 1)} className="px-4 h-full text-gray-500 hover:text-gold transition"><Plus size={16} /></button>
                </div>
              </div>
              <button onClick={add} className="flex-1 h-12 inline-flex items-center justify-center gap-2 rounded-xl bg-gold px-6 text-sm font-semibold uppercase tracking-widest text-gold-foreground hover:opacity-90 transition shadow-md">
                <ShoppingBag size={16} /> Add to Cart · ${(20 * qty).toFixed(2)}
              </button>
            </div>

            <div className="flex items-center gap-2 text-sm text-gray-500 pt-2">
              <Phone size={14} className="text-gold" /> Contact for bulk orders: (601) 573-7624
            </div>
          </div>
        </div>

        {/* Trust badges */}
        <div className="mt-16 pt-10 border-t border-gray-200 flex flex-wrap justify-center gap-12">
          {BADGES.map((b) => (
            <div key={b.label} className="flex flex-col items-center gap-2">
              <b.icon size={28} className="text-gold" />
              <p className="text-xs uppercase tracking-wider text-gray-500">{b.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}