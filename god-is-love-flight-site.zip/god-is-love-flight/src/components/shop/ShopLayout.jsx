import React from 'react';
import { Outlet } from 'react-router-dom';
import { CartProvider } from '@/components/shop/CartContext';
import ShopNavbar from '@/components/shop/ShopNavbar';
import Footer from '@/components/site/Footer';

export default function ShopLayout() {
  return (
    <CartProvider>
      <div className="min-h-screen bg-cream flex flex-col">
        <ShopNavbar />
        <main className="flex-1">
          <Outlet />
        </main>
        <Footer />
      </div>
    </CartProvider>
  );
}