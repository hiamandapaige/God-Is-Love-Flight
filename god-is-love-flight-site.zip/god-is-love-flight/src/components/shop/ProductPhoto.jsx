import React from 'react';
import { Image } from '@/components/ui/image';

// Professional, consistent framing for real product photos.
export default function ProductPhoto({ src, alt, badge, tag, className }) {
  return (
    <div className={`group relative overflow-hidden rounded-3xl border border-border bg-secondary shadow-xl shadow-foreground/10 ${className || ''}`}>
      <Image src={src} alt={alt} fittingType="fill" className="w-full h-full" />
      {/* edge vignette to focus the product */}
      <div className="pointer-events-none absolute inset-0" style={{ background: 'radial-gradient(120% 80% at 50% 42%, transparent 52%, rgba(15,23,42,0.22) 100%)' }} />
      <div className="pointer-events-none absolute inset-x-0 top-0 h-16 bg-gradient-to-b from-black/30 to-transparent" />
      {badge && (
        <div className="absolute top-4 left-4">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-white/90 px-3 py-1 font-mono-tech text-[10px] uppercase tracking-widest text-foreground shadow-sm backdrop-blur">
            <span className="h-1.5 w-1.5 rounded-full bg-gold" /> {badge}
          </span>
        </div>
      )}
      {tag && (
        <div className="absolute bottom-4 right-4">
          <span className="rounded-full bg-foreground/80 px-3 py-1 font-mono-tech text-[10px] uppercase tracking-widest text-background backdrop-blur">{tag}</span>
        </div>
      )}
      <div className="pointer-events-none absolute inset-0 rounded-3xl ring-1 ring-inset ring-white/10" />
    </div>
  );
}