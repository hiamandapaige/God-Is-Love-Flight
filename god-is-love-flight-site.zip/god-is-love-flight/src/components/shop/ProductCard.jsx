import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ShoppingBag, Check } from 'lucide-react';
import { Image } from '@/components/ui/image';
import CustomizableCross from '@/components/shop/CustomizableCross';
import { useCart } from '@/components/shop/CartContext';

export default function ProductCard({ product }) {
  const { addItem } = useCart();
  const [added, setAdded] = useState(false);

  const quickAdd = (e) => {
    e.preventDefault();
    e.stopPropagation();
    const options = product.customizable ? 'Cross: #1E5BFF, GOD: #FFD700, IS: #C0C0C0, 1 John 4:8: #FFD700' : (product.scent ? `Scent: ${product.scent}` : '8 oz. jar');
    addItem({
      key: `${product.id}|${product.customizable ? '#1E5BFF#FFD700#C0C0C0#FFD700' : (product.scent || 'default')}`,
      productId: product.id, name: product.name, price: product.price, qty: 1, options,
      image: product.images[0],
      bodyColor: product.customizable ? '#1E5BFF' : null,
      godColor: product.customizable ? '#FFD700' : null,
      isColor: product.customizable ? '#C0C0C0' : null,
      verseColor: product.customizable ? '#FFD700' : null,
    });
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  };

  return (
    <div className="group relative">
      <div className="relative aspect-square overflow-hidden rounded-2xl bg-gradient-to-br from-amber-50 to-orange-50 border border-gray-100">
        <Link to={`/shop/product/${product.id}`} className="block w-full h-full">
          {product.customizable ? (
            <div className="w-full h-full group-hover:scale-105 transition-transform duration-500">
              <CustomizableCross bodyColor="#1E5BFF" godColor="#FFD700" isColor="#C0C0C0" verseColor="#FFD700" className="relative w-full h-full" />
            </div>
          ) : (
            <Image src={product.images[0]} fittingType="fit" originWidth={1024} originHeight={1024} quality={95} className="w-full h-full group-hover:scale-105 transition-transform duration-500" />
          )}
        </Link>
        {product.badge && (
          <span className="absolute top-3 left-3 inline-flex items-center rounded-full bg-white/90 px-3 py-1 text-[10px] font-semibold uppercase tracking-widest text-black shadow-sm backdrop-blur">
            {product.badge}
          </span>
        )}
        <button onClick={quickAdd} className="absolute bottom-3 right-3 z-10 inline-flex items-center justify-center gap-1.5 rounded-full bg-black px-4 h-10 text-xs font-semibold uppercase tracking-wider text-white hover:bg-gold hover:text-gold-foreground shadow-md transition-all sm:translate-y-2 sm:opacity-0 group-hover:translate-y-0 group-hover:opacity-100">
          {added ? <Check size={14} /> : <ShoppingBag size={14} />}
          <span>{added ? 'Added' : 'Add'}</span>
        </button>
      </div>
      <Link to={`/shop/product/${product.id}`} className="block mt-3">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <h3 className="font-medium text-black leading-tight truncate">{product.name}</h3>
            <p className="text-xs text-gray-400 mt-0.5">{product.subtitle}</p>
          </div>
          <p className="font-semibold text-gold shrink-0">${product.price}</p>
        </div>
      </Link>
    </div>
  );
}