import React from 'react';

export default function CrossSVG({ godColor = '#D4A017', isColor = '#D4A017', loveColor = '#D4A017', className = '' }) {
  return (
    <svg viewBox="0 0 320 480" className={className} xmlns="http://www.w3.org/2000/svg" style={{ filter: 'drop-shadow(0 14px 28px rgba(0,0,0,0.28))' }}>
      <defs>
        <linearGradient id="silverBody" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#dadada" />
          <stop offset="30%" stopColor="#a0a0a0" />
          <stop offset="55%" stopColor="#e2e2e2" />
          <stop offset="78%" stopColor="#909090" />
          <stop offset="100%" stopColor="#6e6e6e" />
        </linearGradient>
        <linearGradient id="edgeHi" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#ffffff" stopOpacity="0.5" />
          <stop offset="45%" stopColor="#ffffff" stopOpacity="0" />
          <stop offset="100%" stopColor="#000000" stopOpacity="0.18" />
        </linearGradient>
        <pattern id="printLayers" x="0" y="0" width="320" height="3.5" patternUnits="userSpaceOnUse">
          <rect width="320" height="1.1" fill="#000000" opacity="0.05" />
        </pattern>
        <radialGradient id="ovalShade" cx="50%" cy="35%" r="65%">
          <stop offset="0%" stopColor="#000" stopOpacity="0.12" />
          <stop offset="100%" stopColor="#000" stopOpacity="0" />
        </radialGradient>
        <filter id="letterDepth" x="-20%" y="-20%" width="140%" height="140%">
          <feDropShadow dx="0.5" dy="1.2" stdDeviation="0.8" floodColor="#000" floodOpacity="0.35" />
        </filter>
      </defs>

      {/* Hanging hole */}
      <circle cx="160" cy="35" r="6" fill="#000" opacity="0.15" />
      <circle cx="160" cy="35" r="4" fill="#5a5a5a" />

      {/* Cross body */}
      <g>
        <rect x="30" y="70" width="260" height="84" rx="16" fill="url(#silverBody)" />
        <rect x="30" y="70" width="260" height="84" rx="16" fill="url(#printLayers)" />
        <rect x="30" y="70" width="260" height="84" rx="16" fill="url(#edgeHi)" />

        <rect x="130" y="70" width="60" height="355" rx="16" fill="url(#silverBody)" />
        <rect x="130" y="70" width="60" height="355" rx="16" fill="url(#printLayers)" />
        <rect x="130" y="70" width="60" height="355" rx="16" fill="url(#edgeHi)" />

        <ellipse cx="160" cy="112" rx="48" ry="40" fill="url(#silverBody)" />
        <ellipse cx="160" cy="112" rx="48" ry="40" fill="url(#printLayers)" />
        <ellipse cx="160" cy="112" rx="48" ry="40" fill="url(#ovalShade)" />

        <rect x="96" y="380" width="26" height="55" rx="8" fill="url(#silverBody)" />
        <rect x="96" y="380" width="26" height="55" rx="8" fill="url(#printLayers)" />
        <rect x="198" y="380" width="26" height="55" rx="8" fill="url(#silverBody)" />
        <rect x="198" y="380" width="26" height="55" rx="8" fill="url(#printLayers)" />
      </g>

      {/* GOD lettering (G + D) — godColor */}
      <g fill={godColor} filter="url(#letterDepth)" fontFamily="'Georgia', 'Times New Roman', serif" fontWeight="700">
        <text x="68" y="128" fontSize="46" textAnchor="middle">G</text>
        <text x="252" y="128" fontSize="46" textAnchor="middle">D</text>
      </g>
      {/* IS — isColor */}
      <text x="160" y="120" fontSize="24" textAnchor="middle" fill={isColor} filter="url(#letterDepth)" fontFamily="'Georgia', serif" fontWeight="700">IS</text>
      {/* LOVE / 1 JOHN 4:8 — loveColor */}
      <text x="160" y="270" fontSize="13" textAnchor="middle" fill={loveColor} fontFamily="'Arial', sans-serif" fontWeight="700" letterSpacing="1.5">1 JOHN 4:8</text>
    </svg>
  );
}